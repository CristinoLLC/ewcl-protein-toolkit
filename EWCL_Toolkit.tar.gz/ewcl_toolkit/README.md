# EWCL Protein Toolkit

This tool allows entropy-based collapse analysis (EWCL) on PDB protein structures without simulation.
